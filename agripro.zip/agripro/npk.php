<?php

	require_once 'DbConnect.php';

$crop = $_GET["crop"];
echo '
{   
    ';

$sql = "SELECT * FROM crop WHERE name='$crop'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
    
    	echo '"success": "1",';
      	echo '"npk": "'. $row["n"].':'. $row["p"].':'. $row["k"].'"';

        
    }
} else {
    echo "0 results";
}

echo 
'}';

$conn->close();    
                    
               
                
                


?>