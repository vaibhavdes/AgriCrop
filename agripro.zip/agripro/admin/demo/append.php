<?php
$fileName='../../csvdata.csv';

$fw = fopen($fileName, 'a');

$cells = array($_POST['n'], $_POST['k'], $_POST['p'], $_POST['season'], $_POST['crop']);

$row = join(",", $cells);

fwrite($fw, $row."\n");

fclose($fw);

header('Location: index.php');

?> 