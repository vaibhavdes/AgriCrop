<?php


	require_once '../../DbConnect.php';

	
	
$name = $_POST["name"];
$n = $_POST["n"];
$p = $_POST["p"];
$k = $_POST["k"];
$season = $_POST["season"];
$ph = $_POST["ph"];
$temperature = $_POST["temperature"];


$sql = "INSERT INTO crop (name,n,p,k,season,ph,temperature)
VALUES ($name,$n,$p,$k,$season,$ph,$temperature)";

if ($conn->query($sql) === TRUE) {
    echo "Crop Data created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>