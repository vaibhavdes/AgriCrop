<?php

	require_once 'DbConnect.php';

$location = $_GET["location"];
echo '
{
    "contacts": [
    ';

$sql = "SELECT * FROM predictions WHERE location='$location'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
    
    	echo '{';
    	echo '"id":"'. $row["id"].'",';
    	echo '"name":"'. $row["name"].'",';
    	echo '"season":"'. $row["season"].'",';
    	echo '"cost":"'. $row[" cost"].'",';
    	
    		echo '"npk": {';
       				echo '"n": "'. $row["n"].'",';
       				echo '"p": "'. $row["p"].'",';
       				echo '"k": "'. $row["k"].'"';
        	echo '}';
        	
        echo '}';
        
    }
} else {
    echo "0 results";
}

echo 
'  ]
}';

$conn->close();    
                    
               
                
                
        


?>