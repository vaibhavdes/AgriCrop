Season Wise Crop Data

Rabi (March - May) 
Kharif (October -  November) 
Zaid (March - June)


http://agritech.tnau.ac.in/agriculture/agri_nutrientmgt_sugarcane.html

http://www.gardenfundamentals.com/fertilizer-selecting-the-right-npk-ratio/

http://www.instructables.com/id/Interfacing-Temperature-and-Humidity-SensorDHT22-W/


Android Project Structure

1) Launcher Activity
	Dashboard.class

* Dashboard

2) Crop Suggestion Based on Soil Data
	MainActivity.class
		Intent to
			Suggestion.class

		*Menu
		Prediction
			prediction.class

3) Location Based Crop Suggestion
	croplocation.class

		*GPS Location
		GPSTracker.class
		
4) User 
	Login
		LoginActivity
	Register
		RegisterActivity
	Profile
		ProfileActivity
			*Processing Request
				RequestHandler.class
5) Crop Rates
	rates.class

* Connections

6) HTTP Web-Connection for Data
	httphandler.class

*Structure

	User Details
		User.class
	Server URLS
		URLs.class
	SharedPreferences (Session)
		SharedPrefManager.class


Web Project Structure

1) Process Request for Suggestion
	index.php

2) APP Register/Login API Call - Connection
	Api.php

3) Dataset
	csvdata.csv

4) Database SQL Connectivity
	Dbconnect.php

5) DecisionTree
	localhost.htm

6) LocationBased Predictions
	predictions.php

	