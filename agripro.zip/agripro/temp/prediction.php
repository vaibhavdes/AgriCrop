<?php
echo '
{
    "crop": [
        {
                "id": "c200",
                "name": "Ravi Tamada",
                "season": "ravi@gmail.com",
                "cost": "0",
                "npk": {
                    "n": "0",
                    "p": "0",
                    "k": "0"
                }
        }      
  ]
}
';
?>
