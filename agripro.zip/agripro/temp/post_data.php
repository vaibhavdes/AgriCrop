<?php
// if text data was posted
if($_POST['alog']=""){
   // print_r($_POST);
   echo 'Received';
}
?>


<form action="index.php" method="post">
<input type="text" name="n">
<input type="text" name="p">
<input type="text" name="k">
<input type="text" name="type">

<input type="submit" name="submit">
</form>

