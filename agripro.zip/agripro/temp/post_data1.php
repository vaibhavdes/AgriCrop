<?php
// if text data was posted
if($_POST){
   // print_r($_POST);
   echo 'Sugarcane';
}
?>