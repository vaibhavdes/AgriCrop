<?php 
require_once __DIR__ . '/vendor/autoload.php';

$n = $_POST['n'];
$p = $_POST['p'];
$k = $_POST['k'];
$algo = $_POST['type'];
$location = $_POST['location'];

use Phpml\Classification\NaiveBayes;
use Phpml\Classification\KNearestNeighbors;
use Phpml\Dataset\CsvDataset;
use Phpml\Dataset\ArrayDataset;
use Phpml\FeatureExtraction\TokenCountVectorizer;
use Phpml\Tokenization\WordTokenizer;
use Phpml\CrossValidation\StratifiedRandomSplit;
use Phpml\FeatureExtraction\TfIdfTransformer;
use Phpml\Metric\Accuracy;
use Phpml\Classification\SVC;
use Phpml\SupportVectorMachine\Kernel;

$dataset = new CsvDataset('csvdata.csv',3, true);

/*$decisiontree= new DecisionTree(50);
$decisiontree->train($dataset->getSamples(), $dataset->getTargets());
echo $decisiontree->getHtml();
*/

/*Month*/

$now = new \DateTime('now');
$month = $now->format('m');

if($month="March" || $month="April" || $month="May" || $month="June" )
{
	$season = "r";
}
elseif($month="October" || $month="November" || $month="December")
{
	$season = "k";
}

if($algo=='NaiveBayes')
{
$classifier = new NaiveBayes();
$classifier->train($dataset->getSamples(), $dataset->getTargets());
echo '{
  "value": "
';
echo $classifier->predict([$n,$p,$k]);
echo '"
}';
}
/* 
echo "<br><br>"
echo "NaiveBayes<br>";;
*/
if($algo=='SVC')
{
$classifiera = new SVC(Kernel::LINEAR, $cost = 1000);
$classifiera->train($dataset->getSamples(), $dataset->getTargets());
echo '{
  "value": "
';
echo $classifiera->predict([$n,$p,$k]);
echo '"
}';
}
/* 
echo "<br><br>";
echo "SVC<br>";
*/
if($algo=='KNN')
{
$classifierk = new KNearestNeighbors();
$classifierk->train($dataset->getSamples(), $dataset->getTargets());
echo '{
  "value": "
';
echo $classifierk->predict([$n,$p,$k]);
echo '"
}';
}
/*
echo "KNearestNeighbors<br>";
*/


?>