package com.pravara.agricrop;

/**
 * Created by Belal on 9/5/2017.
 */

public class URLs {

   // private static final String ROOT_URL = "http://192.168.7.1/agripro/Api.php?apicall=";
   private static final String ROOT_URL = "http://www.vaibhavkurkute.com/project/agripro/Api.php?apicall=";

    public static final String URL_REGISTER = ROOT_URL + "signup";
    public static final String URL_LOGIN= ROOT_URL + "login";

}
