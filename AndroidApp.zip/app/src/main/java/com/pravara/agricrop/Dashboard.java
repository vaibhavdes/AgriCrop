package com.pravara.agricrop;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Locale;

public class Dashboard extends AppCompatActivity implements View.OnClickListener {
	
	//Declaration
    Spinner spinnerctrl;
    Button btn;
    Locale myLocale;
    SharedPreferences langshared;
    SharedPreferences.Editor editor;
    Button crop, soil, profile;
    EditText serveraddress, boltaddress;
	
	//Initialization
	public static final String LOCALE = "en";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        //if the user is not logged in starting the login activity
        if (!SharedPrefManager.getInstance(this).isLoggedIn()) {
            finish();
            startActivity(new Intent(this, LoginActivity.class));
        }

		//set app default language
        langshared = getApplicationContext()
            .getSharedPreferences("MyPref", Context.MODE_PRIVATE);
        editor = langshared.edit();
		
		//get default server address from json
        new yourDataTask().execute();

		//spinner to change app language
        spinnerctrl = (Spinner) findViewById(R.id.spinner1);
        spinnerctrl.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView < ? > parent, View view, int pos, long id) {
                if (pos == 1) {
                    Toast.makeText(parent.getContext(),
                            "You have selected Marathi", Toast.LENGTH_SHORT)
                        .show();
                    setLocale("hi");
                    editor.putString(LOCALE, "hi");
                    editor.commit();
                } else if (pos == 2) {
                    Toast.makeText(parent.getContext(),
                            "You have selected English", Toast.LENGTH_SHORT)
                        .show();
                    setLocale("en");
                    editor.putString(LOCALE, "en");
                    editor.commit();
                }
            }
            public void onNothingSelected(AdapterView < ? > arg0) {
                // TODO Auto-generated method stub                            }
            }
        });

		//Initialization
        serveraddress = (EditText) findViewById(R.id.serveraddress);
        boltaddress = (EditText) findViewById(R.id.boltaddress);
        crop = (Button) findViewById(R.id.crop);
        soil = (Button) findViewById(R.id.soil);
        profile = (Button) findViewById(R.id.profile);
        crop.setOnClickListener(this);
        soil.setOnClickListener(this);
        profile.setOnClickListener(this);



    }

	//get default server addresses
    class yourDataTask extends AsyncTask < Void, Void, JSONObject > {
        @Override
        protected JSONObject doInBackground(Void...params) {

            //String str = "http://192.168.7.10/agripro/data.json";
            String str = "http://www.vaibhavkurkute.com/project/agripro/data.json";

            URLConnection urlConn = null;
            BufferedReader bufferedReader = null;
            try {
                URL url = new URL(str);
                urlConn = url.openConnection();
                bufferedReader = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));

                StringBuffer stringBuffer = new StringBuffer();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuffer.append(line);
                }

                return new JSONObject(stringBuffer.toString());
            } catch (Exception ex) {
                Log.e("App", "yourDataTask", ex);
                return null;
            } finally {
                if (bufferedReader != null) {
                    try {
                        bufferedReader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        @Override
        protected void onPostExecute(JSONObject response) {
            if (response != null) {
                try {
                    serveraddress.setText(response.getString("serveraddress"));
                    boltaddress.setText(response.getString("boltaddress"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }



            }
        }
    }

	//handle button click events
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.crop:
                Intent crop = new Intent(Dashboard.this, croplocation.class);
                crop.putExtra("serveraddress", serveraddress.getText().toString());
                crop.putExtra("boltaddress", boltaddress.getText().toString());
                startActivity(crop);
                break;
            case R.id.soil:
                Intent soil = new Intent(Dashboard.this, MainActivity.class);
                soil.putExtra("serveraddress", serveraddress.getText().toString());
                soil.putExtra("boltaddress", boltaddress.getText().toString());
                startActivity(soil);
                break;

            case R.id.profile:
                Intent profile = new Intent(Dashboard.this, ProfileActivity.class);
                startActivity(profile);
                break;
            default:
                break;
        }
    }
	
	//change app language
    public void setLocale(String lang) {
        myLocale = new Locale(lang);
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.locale = myLocale;
        res.updateConfiguration(conf, dm);
        Intent refresh = new Intent(this, Dashboard.class);
        startActivity(refresh);
    }

}