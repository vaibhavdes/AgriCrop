package com.pravara.agricrop;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    //Component Declaration
    private EditText n, p, k;
    private Button sbtn, vbtn, serverbtn;
    private ProgressDialog progressDialog;
    private String responseStr, serveraddress, boltaddress;
    private Context context;
    private User user;
    RadioGroup radioGroupAlgorithm;
	
	//initialization
    private static final String TAG = "tag";
    private static final String KEY_ADDRESS = "url";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

		//to get user information from shared preference
        user = SharedPrefManager.getInstance(this).getUser();

        //if the user is not logged in
        //starting the login activity
        if (!SharedPrefManager.getInstance(this).isLoggedIn()) {
            finish();
            startActivity(new Intent(this, LoginActivity.class));
        }
		
		
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //TextView algorithm = (TextView)findViewById(R.id.algoithm);
        //algorithm.setVisibility(View.INVISIBLE);
        RadioGroup radioGroup = (RadioGroup)findViewById(R.id.radioAlgorithm);
        radioGroup.setVisibility(View.INVISIBLE);

		//get server address from previous activity through Intent
        Bundle b = getIntent().getExtras();
        serveraddress = b.getString("serveraddress");
        boltaddress = b.getString("boltaddress");

        //Component Initialization
        radioGroupAlgorithm = (RadioGroup) findViewById(R.id.radioAlgorithm);
        n = (EditText) findViewById(R.id.n);
        p = (EditText) findViewById(R.id.p);
        k = (EditText) findViewById(R.id.k);
        sbtn = (Button) findViewById(R.id.sbtn);
        vbtn = (Button) findViewById(R.id.vbtn);

		//progress dialogue Initialization
        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setMessage("Fetching Data");
        progressDialog.setCancelable(true);

		//button action to send N:P:K values to server to get results
        sbtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                try {

                    // url where the data will be posted
                    String postReceiverUrl = serveraddress + "/agripro/index.php";
                    String nvalue = n.getText().toString().trim();
                    String pvalue = p.getText().toString().trim();
                    String kvalue = k.getText().toString().trim();
                    String algorithm = ((RadioButton) findViewById(radioGroupAlgorithm.getCheckedRadioButtonId())).getText().toString();

                    Log.v(TAG, "postURL: " + postReceiverUrl);

                    if (TextUtils.isEmpty(nvalue)) {
                        Toast.makeText(getApplicationContext(), "\n" +
                            "Enter n Value", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (TextUtils.isEmpty(pvalue)) {
                        Toast.makeText(getApplicationContext(), "Enter p Value", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (TextUtils.isEmpty(kvalue)) {
                        Toast.makeText(getApplicationContext(), "Enter k Value", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    progressDialog.show();

                    // HttpClient
                    HttpClient httpClient = new DefaultHttpClient();

                    // post header
                    HttpPost httpPost = new HttpPost(postReceiverUrl);

                    // add your data
                    List < NameValuePair > nameValuePairs = new ArrayList < NameValuePair > (2);
                    nameValuePairs.add(new BasicNameValuePair("n", nvalue));
                    nameValuePairs.add(new BasicNameValuePair("p", pvalue));
                    nameValuePairs.add(new BasicNameValuePair("k", kvalue));
                    nameValuePairs.add(new BasicNameValuePair("location", user.getLocation()));
                    nameValuePairs.add(new BasicNameValuePair("algorithm", algorithm));

                    httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    // execute HTTP post request

                    HttpResponse response = httpClient.execute(httpPost);
                    HttpEntity resEntity = response.getEntity();


                    /*
                     ResponseHandler<String> responseHandler = new BasicResponseHandler();
                        final String response = httpclient.execute(httppost, responseHandler);
                     */
                    Toast.makeText(MainActivity.this, "N:P:K" + nvalue + ":" + pvalue + ":" + kvalue + ":", Toast.LENGTH_SHORT).show();

                    if (resEntity != null) {


                        responseStr = EntityUtils.toString(resEntity).trim();
                        //     Log.v(TAG, "Response: " + responseStr);

                        // you can add an if statement here and do other actions based on the response
                        /* if (responseStr.equalsIgnoreCase("Received")) {
                             runOnUiThread(new Runnable() {
                                 public void run() {
                                     Toast.makeText(MainActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                                 }
                             });
                         } else
                             {

                             }

                             */

                        vbtn.setVisibility(View.VISIBLE);


                    }

                    if (progressDialog.isShowing()) {
                        progressDialog.dismiss();
                    }


                } catch (ClientProtocolException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }



            }
        });

		//button action to view crop suggestion result
        vbtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(MainActivity.this, suggestion.class);
                intent.putExtra("value", responseStr);
                intent.putExtra("boltaddress", boltaddress);
                intent.putExtra("serveraddress", serveraddress);

                startActivity(intent);
            }
        });
		
        //Read Server Response
        //Intent to Suggestion Activity with Add Data
        //Suggestion Activity Functionality Float Button
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
            }
        });
    }

    /*  public class SendPostRequest extends AsyncTask<String, Void, String> {
        String responseStr;
        protected void onPreExecute() {
        }

        protected String doInBackground(String... arg0) {


            return "Data Inserted Succesfully";
        }



        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(MainActivity.this, responseStr , Toast.LENGTH_LONG).show();
        }
    }

*/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_json) {

          //  TextView algorithm = (TextView)findViewById(R.id.algoithm);
           // algorithm.setVisibility(View.VISIBLE);
            RadioGroup radioGroup = (RadioGroup)findViewById(R.id.radioAlgorithm);
            radioGroup.setVisibility(View.VISIBLE);

        } else if (id == R.id.action_location) {

            //TextView algorithm = (TextView)findViewById(R.id.algoithm);
            //algorithm.setVisibility(View.INVISIBLE);
            RadioGroup radioGroup = (RadioGroup)findViewById(R.id.radioAlgorithm);
            radioGroup.setVisibility(View.INVISIBLE);

            return true;
        } else if (id == R.id.action_prediction) {
            Intent intentp = new Intent(MainActivity.this, predictions.class);
            startActivity(intentp);

            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}