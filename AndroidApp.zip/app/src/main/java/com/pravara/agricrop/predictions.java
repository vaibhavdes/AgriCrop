package com.pravara.agricrop;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;


public class predictions extends AppCompatActivity {

    private String TAG = predictions.class.getSimpleName();
    private ProgressDialog pDialog;
    private ListView lv;
    private String var;
	private User user;
    private String serveraddress;
	
    // URL to get contacts JSON
    private static String url;
    ArrayList < HashMap < String, String >> predictionlist;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_predictions);

		//get user information from shared preference
        user = SharedPrefManager.getInstance(this).getUser();

        Bundle b = getIntent().getExtras();

        //get serveraddress from previous activity
        serveraddress = b.getString("serveraddress");

		//address to fetch prediction based on user location
        url = serveraddress + "/agripro/predictions.php?location=" + user.getLocation();
        var = b.getString("value"); // get location

		//initialization of list 
		lv = (ListView) findViewById(R.id.predicitonlist);

		//list of all crop predictions
        predictionlist = new ArrayList < > ();

		//method to fetch prediction from server
        new GetPrediction().execute();
    }
    /**
     * Async task class to get json by making HTTP call
     */
    private class GetPrediction extends AsyncTask < Void, Void, Void > {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(predictions.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();

        }

        @Override
        protected Void doInBackground(Void...arg0) {
            httphandler sh = new httphandler();

            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(url);

            Log.e(TAG, "Response from url: " + jsonStr);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);

                    // Getting JSON Array node
                    JSONArray contacts = jsonObj.getJSONArray("crop");

                    // looping through All Contacts
                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject c = contacts.getJSONObject(i);

                        String id = c.getString("id");
                        String name = c.getString("name");
                        String season = c.getString("season");
                        String cost = c.getString("cost");

                        // Phone node is JSON Object
                        JSONObject phone = c.getJSONObject("npk");
                        String n = phone.getString("n");
                        String p = phone.getString("p");
                        String k = phone.getString("k");

                        // tmp hash map for single contact
                        HashMap < String, String > contact = new HashMap < > ();

                        // adding each child node to HashMap key => value
                        contact.put("id", id);
                        contact.put("name", name);
                        contact.put("season", season);
                        contact.put("cost", cost);

                        // adding contact to contact list
                        predictionlist.add(contact);
                    }
                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG)
                                .show();
                        }
                    });

                }
            } else {
                Log.e(TAG, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG)
                            .show();
                    }
                });

            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();
            /**
             * Updating parsed JSON data into ListView
             * */
            ListAdapter adapter = new SimpleAdapter(
                predictions.this, predictionlist,
                R.layout.list_item, new String[] {
                    "name",
                    "season",
                    "cost"
                }, new int[] {
                    R.id.name,
                        R.id.season, R.id.cost
                });

            lv.setAdapter(adapter);
        }

    }
}