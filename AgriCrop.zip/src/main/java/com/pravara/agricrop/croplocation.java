package com.pravara.agricrop;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import java.util.Locale;

public class croplocation extends AppCompatActivity implements LocationListener {

 //Declaration
 LocationManager locationManager;
 TextView location;
 Button submit;
 private String var;
 double longitude;
 double latitude;
 private TrackGPS gps;
 private String serveraddress;
 
 @Override
 protected void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  setContentView(R.layout.activity_croplocation);

  //Elements Initialization
  location = (TextView) findViewById(R.id.location);
  submit = (Button) findViewById(R.id.submit);

  Bundle b = getIntent().getExtras();
  serveraddress = b.getString("serveraddress");
  
  //Check Location Permission
  if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

   ActivityCompat.requestPermissions(this, new String[] {
    android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);

  }
  
  // check if GPS enabled
  GPSTracker gpsTracker = new GPSTracker(this);

  if (gpsTracker.getIsGPSTrackingEnabled()) {
   String stringLatitude = String.valueOf(gpsTracker.latitude);


   String stringLongitude = String.valueOf(gpsTracker.longitude);


   String city = gpsTracker.getLocality(this);
   Toast.makeText(croplocation.this, "Your Location is:" + " " + city, Toast.LENGTH_SHORT).show();
   Toast.makeText(croplocation.this, "Your Latitude is:" + " " + stringLatitude, Toast.LENGTH_SHORT).show();


  } else {
   Toast.makeText(croplocation.this, "Can't get Location:", Toast.LENGTH_SHORT).show();

   // can't get location
   // GPS or Network is not enabled
   // Ask user to enable GPS/network in settings
   gpsTracker.showSettingsAlert();
  }
    
    getLocation();

	//Get user current location
  gps = new TrackGPS(croplocation.this);
  if (gps.canGetLocation()) {
   longitude = gps.getLongitude();
   latitude = gps.getLatitude();
  }

  //getting the current user location from database
  User user = SharedPrefManager.getInstance(this).getUser();
  //setting the values to the textviews
  location.setText(user.getLocation());
  var = user.getLocation();

  //click event to predict crop based on location
  submit.setOnClickListener(new View.OnClickListener() {
   @Override
   public void onClick(View view) {
    Intent newi = new Intent(croplocation.this, predictions.class);
    newi.putExtra("value",var);
    newi.putExtra("serveraddress", serveraddress);
    startActivity(newi);
   }
  });

 }
 
 
 void getLocation() {
  try {
   locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
   locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 5, this);
  } catch (SecurityException e) {
   e.printStackTrace();
  }
 }

 @Override
 public void onLocationChanged(Location location) {

  try {
   Geocoder geocoder = new Geocoder(this, Locale.getDefault());
   List < Address > addresses = geocoder.getFromLocation(latitude, longitude, 1);
   /*
            locationText.setText(locationText.getText() + "\n"+addresses.get(0).getAddressLine(0)+", "+
                    addresses.get(0).getAddressLine(1)+", "+addresses.get(0).getAddressLine(2));
*/


   int maxAddressLine = addresses.get(0).getMaxAddressLineIndex();

   String countryName = addresses.get(0).getAddressLine(maxAddressLine);
   String stateName = addresses.get(0).getAddressLine(maxAddressLine - 1);
   String cityName = addresses.get(0).getAddressLine(maxAddressLine - 2);

   Toast.makeText(croplocation.this, "Your Location is:" + " " + cityName, Toast.LENGTH_SHORT).show();
   Toast.makeText(croplocation.this, "Your State is:" + " " + stateName, Toast.LENGTH_SHORT).show();
   Toast.makeText(croplocation.this, "Your Country is:" + " " + countryName, Toast.LENGTH_SHORT).show();

  } catch (Exception e) {

  }

 }

 @Override
 public void onProviderDisabled(String provider) {
  Toast.makeText(croplocation.this, "Please Enable GPS and Internet", Toast.LENGTH_SHORT).show();
 }

 @Override
 public void onStatusChanged(String provider, int status, Bundle extras) {

 }

 @Override
 public void onProviderEnabled(String provider) {

 }

}