package com.pravara.agricrop;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class rates extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rates);

        GraphView graph = (GraphView) findViewById(R.id.graph);
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>(new DataPoint[] {
			
			//pass rates datat
                new DataPoint(01, 3262),
                new DataPoint(03, 3252),
                new DataPoint(05, 3252),
                new DataPoint(07, 3250),
                new DataPoint(9, 3240),
                new DataPoint(11, 3240),
                new DataPoint(13, 3240)

        });
        graph.addSeries(series);
    }
}
