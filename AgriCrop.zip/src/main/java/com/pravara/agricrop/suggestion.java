package com.pravara.agricrop;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class suggestion extends AppCompatActivity{

	//declration
    final Context context = this;
    private String suggestion,value,temperature,link;
    private Button btnrate,btntemp,btnnpk;
    private float mv,cel;
	
	//initialization
	private String TAG = MainActivity.class.getSimpleName();   
	private static String url;
    private static String server;
    private static final String KEY_ADDRESS = "url";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggestion);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

		//initialization of components
        btnrate = (Button)findViewById(R.id.btnRate);
        btntemp = (Button)findViewById(R.id.btnTemperature);
        btnnpk = (Button)findViewById(R.id.btnNPK);

        Bundle b = getIntent().getExtras();
        url = b.getString("boltaddress");
        server = b.getString("serveraddress");

		//method to show suggestion of crop
		new GetContacts().execute();

				
		//floating initialization to view extra crop information in browser
        FloatingActionButton floatingActionButton = (FloatingActionButton)findViewById(R.id.fab);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent uv = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
                startActivity(uv);
            }
        });

		//button to get crop rate and move to Rates activity to plot graph
        btnrate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(suggestion.this, rates.class);
                //  intent.putExtra("value",responseStr);
                startActivity(intent);
            }
        });

		//btn to read temperature from bolt iot
        btntemp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),
                        "Reading Temperature ",
                        Toast.LENGTH_LONG)
                        .show();
                new GetTemperature().execute();
            }
        });

		//btn to get min NPK value required for crop
        btnnpk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),
                        "Getting NPK ",
                        Toast.LENGTH_LONG)
                        .show();
                new GetNPK().execute();
            }
        });
        //Initialization



    }

	//to fetch and display suggestion
    private class GetContacts extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            httphandler sh = new httphandler();

			Bundle b = getIntent().getExtras();
            suggestion = b.getString("value");

            // Making a request to url and getting response
            //String jsonStr = sh.makeServiceCall(url);

            String jsonStr = suggestion;
			
            Log.e(TAG, "Response from url: " + jsonStr);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);

                    value = jsonObj.get("value").toString();

                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG)
                                    .show();
                        }
                    });

                }
            } else {
                Log.e(TAG, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG)
                                .show();
                    }
                });

            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            // Dismiss the progress dialog and toast and set text of suggestion
            Toast.makeText(suggestion.this, "Your suggestion is:" + " " + value, Toast.LENGTH_SHORT).show();
            TextView textView = (TextView)findViewById(R.id.suggestion);
            textView.setText(value);
            /**
             * Updating parsed JSON data into ListView
             * */

        }

    }
	
	//get temperature from bolt iot and process to convert digital signal to actual temperature
    private class GetTemperature extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            httphandler sh = new httphandler();

            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(url+"/analogRead?pin=A0");

            Log.e(TAG, "Response from url: " + jsonStr);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);

					//convert digital signal to temperature
                    value = jsonObj.get("value").toString();
                    mv =  ((Float.valueOf(value)/1024)*5000);
                    cel = mv/10;

                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG)
                                    .show();
                        }
                    });

                }
            } else {
                Log.e(TAG, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG)
                                .show();
                    }
                });

            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            // Dismiss the progress dialog
            String celcius = String.valueOf(cel);
            Toast.makeText(suggestion.this, "Current Temperature is:" + " " + celcius +" °C", Toast.LENGTH_SHORT).show();
            TextView textView = (TextView)findViewById(R.id.temperature);
            textView.setText(celcius+" °C");
            /**
             * Updating parsed JSON data into ListView
             * */

        }

    }

	//get npk values from server
    private class GetNPK extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            httphandler sh = new httphandler();

            TextView textView = (TextView)findViewById(R.id.suggestion);
            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(server+"/agripro/npk.php?crop="+textView.getText().toString());

            Log.e(TAG, "Response from url: " + jsonStr);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);

                    value = jsonObj.get("npk").toString();
                    link = jsonObj.get("link").toString();



                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG)
                                    .show();
                        }
                    });

                }
            } else {
                Log.e(TAG, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG)
                                .show();
                    }
                });

            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            // Dismiss the progress dialog
            Toast.makeText(suggestion.this, "Required NPK are:" + value, Toast.LENGTH_SHORT).show();
            btnnpk.setText(value);
            /**
             * Updating parsed JSON data into ListView
             * */

        }

    }
}
